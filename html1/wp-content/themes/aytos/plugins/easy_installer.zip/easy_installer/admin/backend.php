<?php
/**
 *  Name - Installer Panel
 *  Dependency - Core Admin Class
 *  Version - 1.0
 *  Code Name - Nobody
 */

class IOAEasyFrontInstaller extends PLUGIN_IOA_PANEL_CORE {
	
	
	// init menu
	function __construct () { 

		add_action('admin_menu',array(&$this,'manager_admin_menu'));
        add_action('admin_init',array(&$this,'manager_admin_init'));
        
	 }
	
	// setup things before page loads , script loading etc ...
	function manager_admin_init(){	 }	
	
	function manager_admin_menu(){
		
		add_theme_page('Install Demo', 'Install Demo', 'edit_theme_options', 'easint' ,array($this,'manager_admin_wrap'));
		  
				  
	  }

	
	/**
	 * Main Body for the Panel
	 */

	function panelmarkup(){	
	   global $easy_metadata;

	   	//Default Demo Start
		if( (isset($_GET['page']) && $_GET['page'] == 'easint') && isset($_GET['demo_install']) ) :
			easy_import_start();
			EASYFInstallerHelper::beginInstall();
		endif; 

		//Creative Agency Demo Start
		if( (isset($_GET['page']) && $_GET['page'] == 'easint') && isset($_GET['demo_install_blue'])  ) :
			easy_import_start();
			EASYFInstallerHelper::beginInstall();
		endif;
		
		//Business Demo Start
		if( (isset($_GET['page']) && $_GET['page'] == 'easint') && isset($_GET['demo_install_light'])  ) :
			easy_import_start();
			EASYFInstallerHelper::beginInstall();
		endif;
		
		//Startup Demo Start
		if( (isset($_GET['page']) && $_GET['page'] == 'easint') && isset($_GET['demo_install_dark'])  ) :
			easy_import_start();
			EASYFInstallerHelper::beginInstall();
		endif;
		
		?>
		
		<?php if(
			isset($_GET['demo_install']) || 
			isset($_GET['demo_install_blue']) ||
			isset($_GET['demo_install_light']) || 
			isset($_GET['demo_install_dark'])
		):
		
		easy_success_notification(); 
		
		endif; ?>

		<div class="klb-container">

			<div class="klb-12">
				<div class="demo-installer clearfix klbbg">
					<h2><?php echo $easy_metadata['data']->panel_title ?></h2>
					<p><?php echo $easy_metadata['data']->panel_text ?></p>	
				</div>	
			</div>	
			
			
			<div class="klb-4">
				<div class="demo-installer clearfix">
					<img src="<?php echo plugins_url( 'images/default.png', __FILE__ ); ?>">
					<a href="<?php echo admin_url() ?>themes.php?page=easint&amp;demo_install=true" class="button-install"><?php esc_html_e("Install Default Demo","leeway") ?></a>
				</div>	
			</div>	

			<div class="klb-4">
				<div class="demo-installer clearfix">
					<img src="<?php echo plugins_url( 'images/blue.png', __FILE__ ); ?>">
					<a href="<?php echo admin_url() ?>themes.php?page=easint&amp;demo_install_blue=true" class="button-install"><?php esc_html_e("Install Blue Demo","leeway") ?></a>
				</div>	
			</div>	

			<div class="klb-4">
				<div class="demo-installer clearfix">
					<img src="<?php echo plugins_url( 'images/light.png', __FILE__ ); ?>">
					<a href="<?php echo admin_url() ?>themes.php?page=easint&amp;demo_install_light=true" class="button-install"><?php esc_html_e("Install Light Demo","leeway") ?></a>
				</div>	
			</div>
			
			<div class="klb-4">
				<div class="demo-installer clearfix">
					<img src="<?php echo plugins_url( 'images/dark.png', __FILE__ ); ?>">
					<a href="<?php echo admin_url() ?>themes.php?page=easint&amp;demo_install_dark=true" class="button-install"><?php esc_html_e("Install Dark Demo","leeway") ?></a>
				</div>	
			</div>
		</div>

		<?php
	    
	 }
	 

}

new IOAEasyFrontInstaller();