<?php 

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Banner Title
/*-----------------------------------------------------------------------------------*/

function cryptoking_banner_title( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title_first"     => '',
        "title_second"    => '',
        "subtitle"    	  => '',
        "desc"    		  => '',
        "values"          => '',
        "link"          => '',
        "btn_type"          => '',
        "pagescroll"          => '',
    ), $atts) );

	$output  = '';
	$values = (array) vc_param_group_parse_atts($values);

		
	$output .= '<div class="banner_text">';
	$output .= '<h1><span>'.$title_first.'</span> '.$title_second.'</h1>';
	$output .= '<h3>'.$subtitle.'</h3>';
	$output .= '<p>'.$desc.'</p>';
		  
	$output .= '<div class="banner_btn">';
	foreach($values as $v){
		if(isset($v['link'])){
		$link = ( '||' === $v['link'] ) ? '' : $v['link'];
		$link = vc_build_link( $v['link'] );
		$a_href = $link['url'];
		$a_title = $link['title'];
		$a_target = $link['target'];
		}
		
		if($v['btn_type'] == 'type_1'){
			$button_type = 'btn-default';
		} else {
			$button_type = 'btn-border';
		}
		
		$scroll = '';
		if(isset($v['pagescroll'])){
			$scroll .= 'page-scroll nav-link';
		}
		
		if(isset($v['link'])){		
			$output .= '<a class="btn '.esc_attr($button_type).' '.esc_attr($scroll).'" href="'.esc_url($a_href).'" target="'.esc_attr($a_target).'" title="'.esc_attr($a_title).'">'.esc_html($a_title).' <i class="ion-ios-arrow-thin-right"></i></a> ';
		}
	}
	$output .= '</div>';
	$output .= '</div>';

  		return $output;
}

add_shortcode('banner_title', 'cryptoking_banner_title');

/*-----------------------------------------------------------------------------------*/
/* Cryptoking Countdown
/*-----------------------------------------------------------------------------------*/

function cryptoking_countdown( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    => '',
        "datetime"    => '2018/09/06 00:00:00',
        "target"    => '',
        "raised_money"    => '',
        "raised_width"    => '',
        "label_first_raised"    => '',
        "label_first_left"    => '',
        "label_second_raised"    => '',
        "label_second_left"    => '',
        "label_third_raised"    => '',
        "label_third_left"    => '',
        "link"    => '',
        "type"    => '',
    ), $atts) );
	
		$output  = '';
		wp_enqueue_script('countdown');
		wp_enqueue_script('cryptoking_countdown');
		
		$link = ( '||' === $link ) ? '' : $link;
		$link = vc_build_link( $link );
		$a_href = $link['url'];
		$a_title = $link['title'];
		$a_target = $link['target'];
	
		$output  .= '<div class="'.esc_attr($type).' tk_countdown text-center">';
		$output  .= '<div class="banner_text tk_counter_inner">';
		if($title){
		$output  .= '<h3> '.esc_html($title).'</h3>';
		}
		$output  .= '<div class="tk_countdown_time" data-time="'.esc_attr($datetime).'"></div>';
		if($type == 'type2'){
			if($a_title){
			$output  .= '<a href="'.esc_url($a_href).'" title="'.esc_attr($a_title).'" target="'.esc_attr($a_target).'" class="btn btn-default">'.esc_html($a_title).' <i class="ion-ios-arrow-thin-right"></i></a>';
			}
		} else {
			$output  .= '<div class="progress">';
			if($target){
			$output  .= '<div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="'.esc_attr($raised_width).'" aria-valuemin="0" aria-valuemax="100" style="width:'.esc_attr($raised_width).'%"> '.esc_html($raised_money).' </div>';
			if($label_first_raised){
			$output  .= '<span class="progress_label" style="left: '.esc_attr($label_first_left).'%"> <strong> '.esc_html($label_first_raised).' </strong></span>';
			}
			if($label_second_raised){
			$output  .= '<span class="progress_label" style="left: '.esc_attr($label_second_left).'%"> <strong> '.esc_html($label_second_raised).' </strong></span>';
			}
			if($label_third_raised){
			$output  .= '<span class="progress_label" style="left: '.esc_attr($label_third_left).'%"> <strong> '.esc_html($label_third_raised).' </strong></span>';
			}
			$output  .= '<span class="progress_max_val"> '.esc_html($target).' </span>';
			$output  .= '</div>';
			}
			if($a_title){
			$output  .= '<a href="'.esc_url($a_href).'" title="'.esc_attr($a_title).'" target="'.esc_attr($a_target).'" class="btn btn-default">'.esc_html($a_title).' <i class="ion-ios-arrow-thin-right"></i></a>';
			}

		}
			$output  .= '</div>';
		$output  .= '</div>';

  		return $output;
}

add_shortcode('countdown', 'cryptoking_countdown');

/*-----------------------------------------------------------------------------------*/
/* Cryptoking Title
/*-----------------------------------------------------------------------------------*/

function cryptoking_title( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"       => '',
        "subtitle"    => '',
        "type"    	  => '',
        "textalign"   => 'text-left',
    ), $atts) );
	
		$output  = '';

		if($type == 'type2'){
			$output  .= '<div class="title_light '.esc_attr($textalign).'">';
			$output  .= '<span>'.esc_html($subtitle).'</span>';
			$output  .= '<h2>'.esc_html($title).'</h2>';
			$output  .= '</div>';
		} elseif($type == 'type3'){	
			$output  .= '<div class="title_dark '.esc_attr($textalign).'">';
			$output  .= '<span>'.esc_html($subtitle).'</span>';
			$output  .= '<h2>'.esc_html($title).'</h2>';
			$output  .= '</div>';
		} else {
			$output  .= '<div class="title_dark '.esc_attr($textalign).'">';
			$output  .= '<h2>'.esc_html($title).'</h2>';
			$output  .= '</div>';
		}
		
  		return $output;
}

add_shortcode('title', 'cryptoking_title');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Button Btn
/*-----------------------------------------------------------------------------------*/

function cryptoking_btn_button( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"button_icon"         => '',
        "link"                => '',
        "btnalignment"	      => '',
        "button_size"	      => '',		
		"icon_alignment"      => '',
		"css"       		  => '',
		"button_type"   	  => '',
		"buttonname"          => '',
		"download"            => '',
        "icon_fontawesome"   => '',	
        "icon_openiconic"    => '',	
        "icon_typicons"      => '',	
        "icon_entypo"    	 => '',	
        "icon_linecons"      => '',	
        "icon_monosocial"    => '',	
        "icon_ion"      	 => '',	
        "type"    			 => '',
        "activate_rounded"   => '',
        "icon_rounded_ion"   => '',
    ), $atts) );
	
			vc_icon_element_fonts_enqueue( $type ); 

	        $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
			
			$link = ( '||' === $link ) ? '' : $link;
			$link = vc_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			
            $output         = '';
			$klb            = '';
			$alignment   = '';

			$download_attr = '';
			if($download){
				$download_attr .= "download";
			}

            $output .= '<div class="klb-button '.esc_attr($alignment) . esc_attr( $css_class ).'" style="display:inline-block;">';

            $output .= '<a class="kulebe btn btn-default" href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'"  '.esc_attr($download_attr).'>';
			if($activate_rounded){
            $output .= '<span class="'.esc_attr($icon_rounded_ion).'"></span>';
			}
   			    if($button_icon == true){
				  if($icon_alignment == 'right'){
				    
				  } else {
					$output .= '<i class="'.esc_attr($icon_fontawesome) . esc_attr($icon_openiconic) . esc_attr($icon_typicons) . esc_attr($icon_entypo) . esc_attr($icon_linecons) . esc_attr($icon_monosocial) . esc_attr($icon_ion) .'"></i> ';
				  }
				}

            	$output .= esc_attr( $a_title );

				if($button_icon == true){
				  if($icon_alignment == 'right'){
				    $output .= ' <i class="'.esc_attr($icon_fontawesome) . esc_attr($icon_openiconic) . esc_attr($icon_typicons) . esc_attr($icon_entypo) . esc_attr($icon_linecons) . esc_attr($icon_monosocial) . esc_attr($icon_ion) .'"></i>';
				  }
				}			
			$output .= '</a>';

			$output .= '</div> ';

  		return $output;
}

add_shortcode('btn_button', 'cryptoking_btn_button');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Icon Box
/*-----------------------------------------------------------------------------------*/

function cryptoking_icon_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"title"        		 => '',
        "contentm"           => '',
        "icon_fontawesome"   => '',	
        "icon_openiconic"    => '',	
        "icon_typicons"      => '',	
        "icon_entypo"    	 => '',	
        "icon_linecons"      => '',	
        "icon_monosocial"    => '',	
        "icon_ion"      => '',	
        "type"    			 => '',
    ), $atts) );
	
		vc_icon_element_fonts_enqueue( $type ); 
		
		$output         = '';

		$output .= '<div class="klb work_box">';
		$output .= '<div class="box_inner"> ';
		$output .= '<i class="'.esc_attr($icon_fontawesome) . esc_attr($icon_openiconic) . esc_attr($icon_typicons) . esc_attr($icon_entypo) . esc_attr($icon_linecons) . esc_attr($icon_monosocial) . esc_attr($icon_ion) .'"></i>';
		$output .= '<h4>'.esc_html($title).'</h4>';
		$output .= '<p>'.$contentm.'</p>';
		$output .= '</div>';
		$output .= '</div>';

  		return $output;
}

add_shortcode('icon_box', 'cryptoking_icon_box');

/*-----------------------------------------------------------------------------------*/
/* Cryptoking Image Box
/*-----------------------------------------------------------------------------------*/

function cryptoking_image_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"       => '',
        "image_url"    => '',
        "textalign"   => 'text-center',
    ), $atts) );
	
		$image_urls = wp_get_attachment_url( $image_url, 'full' );

		$output  = '';

			$output  .= '<div class="benefit_box '.esc_attr($textalign).'">';
			$output  .= '<img src="'.esc_url($image_urls).'" alt="'.esc_attr($title).'"/>';
			$output  .= '<h6>'.esc_attr($title).'</h6>';
			$output  .= '</div>';
		
  		return $output;
}

add_shortcode('image_box', 'cryptoking_image_box');

/*-----------------------------------------------------------------------------------*/
/* Cryptoking Text Box
/*-----------------------------------------------------------------------------------*/

function cryptoking_text_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"       => '',
        "contentm"    => '',
        "type"    	  => '',
        "textalign"   => 'text-left',
    ), $atts) );
	
		$output  = '';

			$output  .= '<div class="pr_box">';
			$output  .= '<h6>'.esc_html($title).'</h6>';
			$output  .= '<p>'.$contentm.'</p>';
			$output  .= '</div>';
		
  		return $output;
}

add_shortcode('text_box', 'cryptoking_text_box');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Chart List
/*-----------------------------------------------------------------------------------*/

function cryptoking_chart_list( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"     => '',
        "color"     => '',
        "values"          => '',
    ), $atts) );

	$output  = '';
	$values = (array) vc_param_group_parse_atts($values);

	$output .= '<ul class="list_none chart_list">';

	foreach($values as $v){
		$output .= '<li class="'.esc_attr($v['color']).'">'.esc_html($v['title']).'</li>';
	}
	$output .= '</ul>';
  		return $output;
}

add_shortcode('chart_list', 'cryptoking_chart_list');


/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Road Map Carousel
/*-----------------------------------------------------------------------------------*/

function cryptoking_road_map_carousel( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"     => '',
        "subtitle"     => '',
        "values"          => '',
        "complete"          => '',
    ), $atts) );

	$output  = '';
	$values = (array) vc_param_group_parse_atts($values);

	wp_enqueue_script('cryptoking_roadmap');


	foreach($values as $v){
		$completed = '';

		if(isset($v['complete'])){
			$completed .= 'rd_complete';
		}
		$output .= '<div class="item">';
		$output .= '<div class="roadmap_box '.esc_attr($completed).'">';
		$output .= '<div class="roadmap_inner">';
		$output .= '<div class="roadmap_icon icon_gradient_box"></div>';
		$output .= '<h6>'.esc_html($v['title']).'</h6>';
		$output .= '<p>'.esc_html($v['subtitle']).'</p>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
	}

	
  		return '<div class="roadmap owl-carousel small_space">'.$output.'</div>';
}

add_shortcode('road_map_carousel', 'cryptoking_road_map_carousel');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Team Box
/*-----------------------------------------------------------------------------------*/

function cryptoking_team_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "name"     => '',
        "position"     => '',
        "values"          => '',
        "icon_ion"      => '',	
        "image_url"          => '',
        "uniqueid"          => '',
        "icon_ion"          => '',
    ), $atts) );

		$output  = '';
		$values = (array) vc_param_group_parse_atts($values);
		$image_urls = wp_get_attachment_url( $image_url, 'full' );

		$output  .= '<div class="team_box">';
		$output  .= '<div class="team_img text-center"> ';
		$output  .= '<img src="'.esc_url($image_urls).'" alt="'.esc_attr($name).'"/>';
		$output  .= '<div class="social_team list_none">';
		$output  .= '<ul>';
		foreach($values as $v){
			if(isset($v['link'])){
			$link = ( '||' === $v['link'] ) ? '' : $v['link'];
			$link = vc_build_link( $v['link'] );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			}
		if(isset($v['link'])){
		$output  .= '<li><a href="'.esc_url($a_href).'" target="'.esc_attr($a_target).'" title="'.esc_attr($a_title).'"><i class="'.esc_attr($v['icon_ion']).'"></i></a></li> ';
		}
		}
		$output  .= '</ul>';
		$output  .= '</div>';
		$output  .= '</div>';
		$output  .= '<div class="team_info gradient_box text-center">';
		$output  .= '<h4><a href="#'.esc_attr($uniqueid).'" class="content-popup">'.esc_html($name).'</a></h4>';
		$output  .= '<p>'.esc_html($position).'</p>';
		$output  .= '</div>';
		$output  .= '<div id="'.esc_attr($uniqueid).'" class="team_pop mfp-hide">';
		$output  .= '<div class="row m-0">';
		$output  .= '<div class="col-md-6"> <img class="w-100 pt-3 pb-3" src="'.esc_url($image_urls).'" alt="'.esc_attr($name).'"/> </div>';
		$output  .= '<div class="col-md-6">';
		$output  .= '<div class="pt-3 pb-3">';
		$output  .= '<div class="title_dark"> <span>'.esc_html($position).'</span>';
		$output  .= '<h2>'.esc_html($name).'</h2>';
		$output  .= '</div>';
		$output  .= '<div class="social_single_team list_none">';
		$output  .= '<ul>';

		foreach($values as $v){
			if(isset($v['link'])){
			$link = ( '||' === $v['link'] ) ? '' : $v['link'];
			$link = vc_build_link( $v['link'] );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			}
		if(isset($v['link'])){
		$output  .= ' <li><a href="'.esc_url($a_href).'" target="'.esc_attr($a_target).'" title="'.esc_attr($a_title).'"><i class="'.esc_attr($v['icon_ion']).'"></i></a> </li> ';
		}
		}
		
		$output  .= '</ul>';
		$output  .= '</div>';
		$output  .= '<p>'.do_shortcode($content).'</p>';
		$output  .= '</div>';
		$output  .= '</div>';
		$output  .= '</div>';
		$output  .= '</div>';
		$output  .= '</div>';

	
  		return $output;
}

add_shortcode('team_box', 'cryptoking_team_box');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Info List
/*-----------------------------------------------------------------------------------*/

function cryptoking_info_list($atts){
	extract(shortcode_atts(array(
       	'values'      => '',
       	'title'          => '',
       	'contentm'       => '',
		'icon_ion'    => '',
    ), $atts));
    
	$out = '';

	
	$values = (array) vc_param_group_parse_atts($values);
	$out .= '';

	foreach($values as $v){
	$out .= '<li class="input-group-prepend align-items-center">';
	$out .= '<i class="'.esc_attr($v['icon_ion']).'"></i>';
	$out .= '<div class="contact_detail">';
	$out .= '<span>'.esc_html($v['title']).'</span>';
	$out .= '<p>'.$v['contentm'].'</p>';
	$out .= '</div>';
	$out .= '</li>';
	}
	
	return  '<ul class="list_none contact_info mt-margin">'.$out.'</ul>';

}
add_shortcode('info_list', 'cryptoking_info_list');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Social List
/*-----------------------------------------------------------------------------------*/

function cryptoking_social_list($atts){
	extract(shortcode_atts(array(
       	'values'      => '',
       	'link'       => '',
		'icon_ion'    => '',
        "textalign"   => 'text-center',

    ), $atts));
    
	$out = '';

	$values = (array) vc_param_group_parse_atts($values);
	$out .= '';

	foreach($values as $v){
		if(isset($v['link'])){
		$link = ( '||' === $v['link'] ) ? '' : $v['link'];
		$link = vc_build_link( $v['link'] );
		$a_href = $link['url'];
		$a_title = $link['title'];
		$a_target = $link['target'];
		}
		
		if(isset($v['link'])){	
		$out .= '<li><a href="'.esc_url($a_href).'" target="'.esc_attr($a_target).'" title="'.esc_attr($a_title).'"><i class="'.esc_attr($v['icon_ion']).'"></i></a></li> ';
		}
	}
	
	return  '<ul class="list_none footer_social '.esc_attr($textalign).'">'.$out.'</ul>';

}
add_shortcode('social_list', 'cryptoking_social_list');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Subscribe Form
/*-----------------------------------------------------------------------------------*/

function cryptoking_subscribe_form($atts){
	extract(shortcode_atts(array(
       	'subscribe_form_id'      => '',
       	'title'       => '',
		'font_color'    => '',
        "textalign"   => 'text-center',

    ), $atts));
    
		$out = '';

		$out .= '<div class="newsletter_form large_space '.esc_attr($textalign).'">';
		if($title){
		$out .= '<h4 class="footer_title" style="color:'.esc_attr($font_color).'">'.esc_html($title).'</h4>';
		}
		$out .= do_shortcode('[mc4wp_form id="'.$subscribe_form_id.'"]');
		$out .= '</div>';
		
	return  $out;

}
add_shortcode('subscribe_form', 'cryptoking_subscribe_form');


/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Login Register
/*-----------------------------------------------------------------------------------*/

function cryptoking_login_register_form( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "placeholder"    => 'Enter Movies or Series Title',
        "bgimage"    => '',
        "bgcolor"    => 'rgba(26, 26, 26, .9)',
    ), $atts) );

            $output  = '';
            $output  .= '<div class="small-dialog login-register">';
			if(is_user_logged_in()) {

				$output  .= '<div class="signin-wrapper logged">';
				$output  .= '<div class="small-dialog-headline">';
				$output  .= '<div class="title_dark text-center"><h2>'.esc_html__('Log Out','cryptoking').'</h2></div>';
				$output  .= '</div>';
				$output  .= '<div class="small-dialog-content">';

				$current_user = wp_get_current_user();

				$output  .= '<div class="bottom-links">';
				$output  .= '<a class="welcome">'.esc_html__('Welcome ','cryptoking') . $current_user->user_login.'</a>';
				$output  .= '<a href="'.wp_logout_url(home_url()).'" class="logoutright">'.esc_html__('Log Out','cryptoking').'</a>';
				$output  .= '</div>';
				$output  .= '</div>';
				$output  .= '</div>';
			} else {
				$output  .= '<div class="signin-wrapper">';
				$output  .= '<div class="title_dark text-center"><h2>'.esc_html__('Login','cryptoking').'</h2></div>';
				ob_start();
				$output .= wp_login_form() . ob_get_clean();
				$output  .= '<div class="bottom-links">';
				$output  .= '<a class="signUpClick">'.esc_html__('Sign up','cryptoking').'</a>';
				$output  .= '<a class="forgetPasswordClick pull-right">'.esc_html__('Forgot Password','cryptoking').'</a>';
				$output  .= '</div>';
				$output  .= '</div>';
			}
					
					
			if(!is_user_logged_in()) {
            $output  .= '<div class="signup-wrapper">';
            $output  .= '<div class="small-dialog-headline">';
            $output  .= '<div class="title_dark text-center"><h2>'.esc_html__('Sign up','cryptoking').'</h2></div>';
            $output  .= '</div>';
            $output  .= '<div class="small-dialog-content">';

            $output  .= '<form name="registerform" action="'.site_url('wp-login.php?action=register', 'login_post').'" method="post">';
            $output  .= '<p>';
            $output  .= '<label for="user_login">'.esc_html__('Username','cryptoking').'</label>';
            $output  .= '<input type="text" name="user_login" id="user_login" value="">';
            $output  .= '</p>';
            $output  .= '<p>';
            $output  .= '<label for="user_email">'.esc_html__('E-mail','cryptoking').'</label>';
            $output  .= '<input type="text" name="user_email" id="user_email" value="">';
            $output  .= '</p>';
            $output  .= '<p style="display:none">';
            $output  .= '<label for="confirm_email">'.esc_html__('Please leave this field empty','cryptoking').'</label>';
            $output  .= '<input type="text" name="confirm_email" id="confirm_email" value="">';
            $output  .= '</p>';
            $output  .= '<p id="reg_passmail">'.esc_html__('A password will be e-mailed to you.','cryptoking').'</p>';
            $output  .= '<input type="hidden" name="redirect_to" value="'.site_url('login/?action=register&success=1', 'login_post').'" />';
            $output  .= '<p class="submit"><input class="btn btn-default" type="submit" name="wp-submit" value="'.esc_html__('Register','cryptoking').'" /></p>';
            $output  .= '</form>';

            $output  .= '<div class="bottom-links">';
            $output  .= '<a class="signInClick"> '.esc_html__('Sign in','cryptoking').'</a>';
            $output  .= '<a class="forgetPasswordClick pull-right">'.esc_html__('Forgot Password','cryptoking').'</a>';
            $output  .= '</div>';
            $output  .= '</div>';
            $output  .= '</div>';
					
					
					
            $output  .= '<div class="forgetpassword-wrapper">';
            $output  .= '<div class="small-dialog-headline">';
            $output  .= '<div class="title_dark text-center"><h2>'.esc_html__('Forgotten Password','cryptoking').'</h2></div>';
            $output  .= '</div>';
            $output  .= '<div class="small-dialog-content">';
			
            $output  .= '<form name="lostpasswordform" action="'.site_url('wp-login.php?action=lostpassword', 'login_post').'" method="post">';
            $output  .= '<p>';
            $output  .= '<input type="text" name="user_login" value="" placeholder="'.esc_attr__('Username or E-mail:','cryptoking').'">';
            $output  .= '</p>';
            $output  .= '<input type="hidden" name="redirect_to" value="'.site_url('/login/?action=forgot&success=1', 'login_post').' ">';
            $output  .= '<p class="submit"><input class="btn btn-default" type="submit" name="wp-submit" value="'.esc_html__('Get New Password','cryptoking').'" /></p>';
            $output  .= '</form>';

            $output  .= '<div class="bottom-links">';
            $output  .= '<a class="cancelClick">'.esc_html__('Cancel','cryptoking').'</a>';
            $output  .= '</div>';
            $output  .= '</div>';
            $output  .= '</div>';
					
			}
            $output  .= '</div>';
		


  		return '<div class="authorize_box">
                    <div class="authorize_form">'.$output.'</div></div>';
}

add_shortcode('login_register_form', 'cryptoking_login_register_form');

/*-----------------------------------------------------------------------------------*/
/*	Cryptoking Br
/*-----------------------------------------------------------------------------------*/

function cryptoking_br() {
   return '<br />';
}

add_shortcode('br', 'cryptoking_br');