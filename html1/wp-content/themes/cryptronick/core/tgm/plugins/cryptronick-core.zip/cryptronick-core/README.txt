=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://themeforest.net/user/blendpixels
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html